package io.spring;

import java.time.LocalDateTime;

import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.job.flow.FlowExecutionStatus;
import org.springframework.batch.core.job.flow.JobExecutionDecider;

public class ByeDecider implements JobExecutionDecider {

	@Override
	public FlowExecutionStatus decide(JobExecution jobExecution, StepExecution stepExecution) {
	
		// TODO Auto-generated method stub

		String result = LocalDateTime.now().getHour()>12?"PRESENT":"NOT PRESENT";
	
		System.out.println("result"+result);
		
		return new FlowExecutionStatus(result);
	}

}
