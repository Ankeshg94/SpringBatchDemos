package com.springbatch.readingcsvfilesdemoConfiguration;

import ch.qos.logback.core.net.SyslogOutputStream;
import com.springbatch.POJO.Order;
import com.springbatch.readingcsvfilesdemoUtils.OrderFieldSetMapper;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.mapping.DefaultLineMapper;
import org.springframework.batch.item.file.transform.DelimitedLineTokenizer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.FileSystemResource;

import java.util.List;

@Configuration
@EnableBatchProcessing
public class JobConfiguration {

    @Autowired
    private JobBuilderFactory jobBuilderFactory;

    @Autowired
    private StepBuilderFactory stepBuilderFactory;

    private static String[] tokens = {"order_id", "first_name", "last_name", "email", "cost", "item_id", "item_name", "ship_date"};

    public ItemReader<Order> itemReader() {
        FlatFileItemReader itemReader = new FlatFileItemReader<Order>();
        itemReader.setLinesToSkip(1);
        itemReader.setResource(new FileSystemResource("/Users/guptaan/workspace/SpringBatchDemos/readingcsvfilesdemo/src/main/resources/shipped_orders.csv"));

        DefaultLineMapper<Order> lineMapper = new DefaultLineMapper<Order>();
        DelimitedLineTokenizer tokenizer = new DelimitedLineTokenizer();
        tokenizer.setNames(tokens);

        lineMapper.setLineTokenizer(tokenizer);

        lineMapper.setFieldSetMapper(new OrderFieldSetMapper());
        itemReader.setLineMapper(lineMapper);
        return itemReader;
    }


    @Bean
    public Step readData() {
        return this.stepBuilderFactory.get("chunkReading").<Order, Order>chunk(5).reader(itemReader()).writer(

                new ItemWriter<Order>() {
                    @Override
                    public void write(List<? extends Order> list) throws Exception {
                        System.out.println(String.format("Received list of size %s", list.size()));
                        list.forEach(System.out::println);
                    }
                }

        ).build();
    }

    @Bean
    public Job job() {
        return this.jobBuilderFactory.get("readingOrdersJob").start(readData()).build();
    }

}
