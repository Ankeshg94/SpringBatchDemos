package com.springbatch.readingcsvfilesdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan("com.springbatch.readingcsvfilesdemoConfiguration")
public class ReadingcsvfilesdemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(ReadingcsvfilesdemoApplication.class, args);
    }

}
