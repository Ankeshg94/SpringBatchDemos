package com.springbatch.readingcsvfilesdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReadingcsvfilesdemoApplicationTests {

    @Test
    void contextLoads() {
    }

}
