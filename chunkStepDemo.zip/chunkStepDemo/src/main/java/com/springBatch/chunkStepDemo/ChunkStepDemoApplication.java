package com.springBatch.chunkStepDemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan("com.springBBatch.chunkStepDemo.JobConfiguration")
public class ChunkStepDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ChunkStepDemoApplication.class, args);
	}

}
