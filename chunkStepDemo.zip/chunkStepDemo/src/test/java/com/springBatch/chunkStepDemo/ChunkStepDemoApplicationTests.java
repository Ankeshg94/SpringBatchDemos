package com.springBatch.chunkStepDemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChunkStepDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
