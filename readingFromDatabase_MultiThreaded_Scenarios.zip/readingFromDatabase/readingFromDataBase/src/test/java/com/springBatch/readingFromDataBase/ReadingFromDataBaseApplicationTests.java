package com.springBatch.readingFromDataBase;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReadingFromDataBaseApplicationTests {

	@Test
	void contextLoads() {
	}

}
