package com.springBatch.writingFlatFiles;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan("com.springBatch.jobConfiguration")
public class WritingFlatFilesApplication {

	public static void main(String[] args) {
		SpringApplication.run(WritingFlatFilesApplication.class, args);
	}

}
