package com.springBatch.jobConfiguration;

import javax.sql.DataSource;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.database.JdbcBatchItemWriter;
import org.springframework.batch.item.database.PagingQueryProvider;
import org.springframework.batch.item.database.builder.JdbcBatchItemWriterBuilder;
import org.springframework.batch.item.database.builder.JdbcPagingItemReaderBuilder;
import org.springframework.batch.item.database.support.SqlPagingQueryProviderFactoryBean;
import org.springframework.batch.item.file.FlatFileItemWriter;
import org.springframework.batch.item.file.transform.BeanWrapperFieldExtractor;
import org.springframework.batch.item.file.transform.DelimitedLineAggregator;
import org.springframework.batch.item.validator.BeanValidatingItemProcessor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.FileSystemResource;

import com.springBatch.pojo.Order;
import com.springBatch.utils.OrderItemPreparedStatementSetter;
import com.springBatch.utils.OrderRowMapper;

@Configuration
@EnableBatchProcessing
public class JobConfiguration {

    @Autowired
    private JobBuilderFactory jobBuilderFactory;

    @Autowired
    private StepBuilderFactory stepBuilderFactory;

    @Autowired
    private DataSource dataSource;


    private static String[] names = {"orderId", "firstName", "lastName", "email", "cost", "itemId", "itemName", "shipDate"};

    public static String ORDER_SQL = "select order_id, first_name, last_name, email, cost, item_id, item_name,ship_date from SHIPPED_ORDER order by order_id";
    
    public static String INSERT_ORDER_SQL = "insert into "
    		+ "SHIPPED_ORDER_OUTPUT(order_id,first_name,last_name,email,item_id,item_name,cost,ship_date)"
    		+ "values(?,?,?,?,?,?,?,?)";

    @Bean
    public PagingQueryProvider queryProvider() throws Exception {


        SqlPagingQueryProviderFactoryBean factoryBean = new SqlPagingQueryProviderFactoryBean();
        factoryBean.setSelectClause("select order_id, first_name, last_name, email, cost, item_id, item_name,ship_date");
        factoryBean.setFromClause("from SHIPPED_ORDER");
        factoryBean.setSortKey("order_id");
        factoryBean.setDataSource(this.dataSource);

        return factoryBean.getObject();
    }

    @Bean
    public ItemReader<Order> itemReader() throws Exception {

        return new JdbcPagingItemReaderBuilder<Order>().dataSource(dataSource).name("JdbcPagingItemReader")
                .queryProvider(queryProvider()).rowMapper(new OrderRowMapper()).pageSize(5).build();


    }
    
    @Bean
    public ItemProcessor<Order, Order> OrderItemValidatingProcessor() {
		
    	BeanValidatingItemProcessor<Order> itemProcessor = new BeanValidatingItemProcessor<>();
    	itemProcessor.setFilter(true);
    	return itemProcessor;
	}
    
    
    @Bean

    public ItemWriter<? super Order> itemWriter() {
  	
    return new JdbcBatchItemWriterBuilder<Order>()
    		.dataSource(dataSource).sql(INSERT_ORDER_SQL)
    		.itemPreparedStatementSetter(new OrderItemPreparedStatementSetter())
    		.build();
    	
  	}

    @Bean
    public Step readData() throws Exception {
        return this.stepBuilderFactory.get("chunkReading").<Order, Order>chunk(5)
        		.reader(itemReader())
        		.processor(OrderItemValidatingProcessor())
        		.writer(

                itemWriter()
        ).build();
    }



//Writing to dataBase job
	@Bean
    public Job job() throws Exception {
        return this.jobBuilderFactory.get("writingOrdersJob").start(readData()).build();
    }

}
