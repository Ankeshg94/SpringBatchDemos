package com.springBatch.jobconfiguration;

import com.springBatch.pojo.Order;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.database.builder.JdbcCursorItemReaderBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import com.springBatch.utils.OrderRowMapper;

import javax.sql.DataSource;
import java.util.List;

@Configuration
@EnableBatchProcessing
public class JobConfiguration {

    @Autowired
    private JobBuilderFactory jobBuilderFactory;

    @Autowired
    private StepBuilderFactory stepBuilderFactory;

    @Autowired
    private DataSource dataSource;


    private static String[] tokens = {"order_id", "first_name", "last_name", "email", "cost", "item_id", "item_name", "ship_date"};

    public static String ORDER_SQL = "select order_id, first_name, last_name, email, cost, item_id, item_name,ship_date from SHIPPED_ORDER order by order_id";


    public ItemReader<Order> itemReader() {

        return  new JdbcCursorItemReaderBuilder<Order>()
                .dataSource(dataSource).name("jdbcCursorItemReader").sql(ORDER_SQL)
                .rowMapper(new OrderRowMapper()).build();

    }

    @Bean
    public Step readData() {
        return this.stepBuilderFactory.get("chunkReading").<Order, Order>chunk(5).reader(itemReader()).writer(

                new ItemWriter<Order>() {
                    @Override
                    public void write(List<? extends Order> list) throws Exception {
                        System.out.println(String.format("Received list of size %s", list.size()));
                        list.forEach(System.out::println);
                    }
                }

        ).build();
    }

    @Bean
    public Job job() {
        return this.jobBuilderFactory.get("readingOrdersJob").start(readData()).build();
    }

}
