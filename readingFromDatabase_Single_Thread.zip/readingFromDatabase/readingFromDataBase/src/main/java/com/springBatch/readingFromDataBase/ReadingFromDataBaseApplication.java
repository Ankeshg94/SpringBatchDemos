package com.springBatch.readingFromDataBase;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan("com.springBatch.jobconfiguration")
public class ReadingFromDataBaseApplication {

	public static void main(String[] args) {
		SpringApplication.run(ReadingFromDataBaseApplication.class, args);
	}

}
